# Define a function
def world():
    print("Hello, World!")

# Define a variable
shark = "Sammy"
